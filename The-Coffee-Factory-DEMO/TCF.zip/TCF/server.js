// listening for request
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const {Server} = require('socket.io')

process.on('uncaughtException', (err) => {
  console.log('Uncaught Rejection. Shutting down...');
  console.log(err.name, err.message);
  process.exit(1); // 0 is success, 1 is uncaught exception
});

dotenv.config({ path: './config.env' });
const app = require('./app');

mongoose
  .connect(process.env.DATABASE, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useFindAndModify: false,
  })
  .then(() => {
    console.log('DB connection successful!');
  });

const server = require('http').Server(app);
const io = new Server(server);

const port = 3000 || process.env.PORT;
server.listen(port, () => {
  console.log(`App is running on port ${port}...`);
});

// const orderController = require('./controllers/orderController.js');
// orderController.
process.on('unhandledRejection', (err) => {
  console.log('Unhandled Rejection. Shutting down...');
  console.log(err.name, err.message);
  server.close(() => {
    process.exit(1); // 0 is success, 1 is uncaught exception
  });
});

exports.io = io;